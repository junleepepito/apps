# fbdownloader-starter-repo

A simple, minimal **Facebook video downloader** project.  
This repo demonstrates how to build a **Node.js backend (hosted on Vercel)** and a **static frontend (hosted on GitHub Pages)**.

## 🚀 Instructions
See README inside for full details.
