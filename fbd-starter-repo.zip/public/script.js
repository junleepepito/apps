const API_BASE = "https://YOUR_VERCEL_URL.vercel.app"; // replace with actual Vercel backend URL

document.getElementById("downloadForm").addEventListener("submit", async (e) => {
  e.preventDefault();
  const url = document.getElementById("fbUrl").value.trim();
  const resultDiv = document.getElementById("result");
  resultDiv.innerHTML = "Extracting...";

  try {
    const res = await fetch(`${API_BASE}/api/info?url=${encodeURIComponent(url)}`);
    if (!res.ok) throw new Error("Failed to fetch video info");

    const data = await res.json();
    if (data.downloadUrl) {
      resultDiv.innerHTML = `
        <p><strong>Title:</strong> ${data.title || "Untitled"}</p>
        <a href="${data.downloadUrl}" target="_blank" class="contrast" download>⬇️ Download Video</a>
      `;
    } else {
      resultDiv.innerHTML = "<p>Could not extract video. Maybe it's private?</p>";
    }
  } catch (err) {
    resultDiv.innerHTML = `<p>Error: ${err.message}</p>`;
  }
});
